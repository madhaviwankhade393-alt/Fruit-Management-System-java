package com.fruit;

import java.util.Scanner;

public class OperationsF {
	public OperationsF(){
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter id");
		int id=sc.nextInt();
		
		System.out.println("Enter category");

         String category=sc.next(); 	
         
         System.out.println("Enter price");

	     int price=sc.nextInt();
	     
	     System.out.println("Enter taste");

         String taste=sc.next();
    }
	
	 
	
	    
//	public void add()
	{ 
		String temp= toString(); 
//		OperationsF f1=new OperationsF();
//		System.out.println("Add your fruit");
		String array[]= {"a"};
		array[0] =temp;
		System.out.println(array[0]);
		
	
			
	} 

}

